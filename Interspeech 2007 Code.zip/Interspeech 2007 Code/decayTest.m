% Interspeech 2007 Submission: formant tracking script

% Toggle mutiple runs
runNum = 1;
switch(run)
    case 1, % Toggle coasting on/off, toggle full VAR on/off (Discussion)
        quantThresh = [0 0.15]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [0 1];   % boolean variable (for VAR)
        frmts =  {[1 2 3]};
    case 2, % Coasting on, VAR on, vary VAR indices (Tables 1 and 2)
        quantThresh = [0.15]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [1];   % boolean variable (for VAR)
        frmts =  {[1 2], [2 3], [1 3]};
    otherwise
        error('Invalid runNum specified');
end

% Fixed (empirically determined to be best) parameters
coastJoint = [1];  % 1 (fixed boolean always)
sigExp = [1]; % 1 (fixed real always)
timitInd = 1:516; % 516 (fixed always; all VTR utterances)

for i = 1:length(coastJoint)
    for j = 1:length(quantThresh)
        for k = 1:length(useCorr)
            for m = 1:length(sigExp)
        [rmse rmseAll] =  MyLoopTrackExp(timitInd,coastJoint(i),quantThresh(j),useCorr(k),sigExp(m));
        save(['rmse_3_3500_cj' int2str(coastJoint(i)) '_qt' int2str(100*quantThresh(j)) '_uc' int2str(useCorr(k)) '_se' int2str(100*sigExp(m)) '_ws_av'],'rmse','rmseAll');
        clear rmse rmseAll
            end
        end
    end
end

