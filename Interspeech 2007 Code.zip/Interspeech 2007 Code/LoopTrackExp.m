function LoopTrackExp()
%
% Function Loops TrackExp to process all TIMIT data examples
% 
% Inputs : useCoast is coasting flag, 1 to use, 0 otherwise
% Created : 3/23/2007
% Last Updated : 3/24/2007

% Flag Declarations
mFlag = 0;      %Use masking technique to compute error
eFlag = 1;      %Use if Extended Kalman Filter was used to track
sFlag = 1;      %Use if smoother was used to track
runBatch = 0;   %Use if batch run is desired
runSNR = 1;     %Use if SNR loop is desired

% Parameters for Batch run
snrValue = 25;

% Parameters for SNR run
index = 23;

% Measurement Runs
if (runBatch)
    
    % Test Indices
    testInd = 1:1:1;

    % Loop Calls to TrackExp
    for loopInd = 1:length(testInd)
        E(loopInd) = TrackExp('Timit',snrValue,15,16000,4,[],[],testInd(loopInd));
    end

    % Calculate Avg RMSE ocf WS, ASSUMING DATA IS ALLIGNED!!!!!!!!
    [EKFrmse EKFrelRmse EKSrmse EKSrelRmse WSrmse WSrelRmse numEst] = getAvgRMSE(E,mFlag,eFlag,sFlag);

    % Plot Averaged MSE values
    plotAvgRMSE(EKFrmse,EKFrelRmse,EKSrmse,EKSrelRmse,WSrmse,WSrelRmse, numEst)
    my_fmakep5;
    
elseif (runSNR)
    
    SNRtests = 24:1:25;
    
    % Loop Calls to TrackExp
    for ii = 1:length(SNRtests)
        % Run TrackExp with proper SNR values
        E(ii) = TrackExp('Timit',SNRtests(ii),15,16000,4,[],[],index);
    
        % Calculate Avg RMSE ocf WS, ASSUMING DATA IS ALLIGNED!!!!!!!!
        [EKFrmse(:,ii) EKFrelRmse(:,ii) EKSrmse(:,ii) EKSrelRmse(:,ii) WSrmse(:,ii) WSrelRmse(:,ii) numEst(:,ii)] = getAvgRMSE(E,mFlag,eFlag,sFlag);
    end
        % Plot Results
        plotSNRRes(EKFrmse, EKFrelRmse, EKSrmse, EKSrelRmse, SNRtests)

    
end   
    debug = 0;
