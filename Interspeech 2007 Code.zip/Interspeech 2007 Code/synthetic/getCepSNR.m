function [cepSNR,oNoiseVar] = getCepSNR(y,nosY)
%
% Function uses cepstral coefficients generated from "true" and noisey
% waveforms to calculate the SNR of the noisey observations, has extra
% option to use either the averaged oNoiseVar or the element-wise oNoiseVar
% Created : 3/25/2007
% Last Updated : 3/25/2007

% Number of Observations
numObser = size(y,2);

% Determine Noise Power to Add for given SNR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculate the signal and noise power
nosPow = sum((y - nosY).^2,2)/numObser;
sigPow = sum(y.^2,2)/numObser;

% For the given SNR ratio, compute the neccessary average noise:
% 10*log10(avg_signal_power/noise_power) = SNR_dB
oNoiseVar = nosPow;                        % Indpendent
%oNoiseVar = mean(nosPow);                   % Averaged Noise Var

cepSNR = 10*log10(sigPow./nosPow);         % Independent
%cepSNR = 10*log10(mean(sigPow)/oNoiseVar);  % Averaged Noise Var
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

debug = 0;