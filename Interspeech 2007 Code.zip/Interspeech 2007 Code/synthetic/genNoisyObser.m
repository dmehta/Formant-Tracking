function [C_final, oNoiseVar] = genNoisyObser(SNR, state_progression, BW_progress, cep_order,f_samp)
%function [C_final, oNoiseVar] = genNoisyObser(SNR, state_progression, BW_progress, cep_order,f_samp)
% Generate noisy observations given true formant state data

% Get Desired lengths
[rows columns] = size(state_progression);

% Calculate Observations for state progression
for kk = 1:columns
    C(:,kk) = fb2cp(state_progression(:,kk),BW_progress(:,kk),cep_order,f_samp);
end

% Add observation noise
[C_final, oNoiseVar] = addONoise(C, SNR);
