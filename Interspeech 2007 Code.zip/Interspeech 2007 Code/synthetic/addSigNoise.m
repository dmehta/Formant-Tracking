function [y, ss_n] = addSigNoise(x, snr_dB)
%
% Adds AWGN to waveform for a given SNR
% Created : 3/24/2007
% Last Updated : 3/24/2007

ss_n = var(x)/(10^(snr_dB/10)); % set noise variance;
n = sqrt(ss_n).*randn(length(x),1); % generate noise
y = x + n; % compute observed signal
