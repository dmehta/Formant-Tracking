function [states,C_final,oNoiseVar,BW_data] = genSyntheticDataSNR(pNoiseVar,SNR,f_samp,numObser,cep_order,initState,initBW)
%function [states,C_final,oNoiseVar,BW_data] = genSyntheticDataSNR(pNoiseVar,SNR,f_samp,numObser,cep_order,initState,initBW)
% Generates synthetic data from model

% Generate data via random walk model
num_states = size(initState,1);
states(:,1) = initState';
for i = 2:numObser
    states(:,i) = states(:,i-1) + sqrt(pNoiseVar)*randn(num_states,1);
end

% Generate "true" observations corresponding to the state progression
% via the Taylor expansion equations in Deng's approach, note no noise is
% added
for kk=1:numObser
    C(:,kk) = fb2cp(states(:,kk),initBW,cep_order,f_samp);
end

% Add observation noise
[C_final, oNoiseVar] = addONoise(C, SNR);

% Put together BW data
BW_data = repmat(initBW',1,numObser);
