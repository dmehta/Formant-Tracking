function [C_final, oNoiseVar] = addONoise(C, SNR)
%function [C_final, oNoiseVar] = addONoise(C, SNR)
% Computes necessary noise variance for a given SNR, and adds it

% Number of Observations
num_obser = length(C(1,:));

% Cepstral Order
cep_order = length(C(:,1));

% Determine Noise Power to Add for given SNR
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Construct the Volume of the C's and average them over all observations
for kk = 1:num_obser
    volume_C(kk) = (sum(C(:,kk).^2));
end

avg_vol_C = sum(volume_C)/num_obser;

% For the given SNR ratio, compute the neccessary average noise:
% 10*log10(avg_signal_power/noise_power) = SNR_dB
avg_noise_volume  = avg_vol_C/(10^(SNR/10));
oNoiseVar = avg_noise_volume/cep_order;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Add noise back into C's
for kk = 1:num_obser
    C_final(:,kk) = C(:,kk) + sqrt(oNoiseVar)*randn(cep_order,1);
end

debug = 0;
if debug,
    for i = 1:num_obser, 
        local_snr(i) = 20*log10(norm(C_final(:,i))/norm(C_final(:,i)-C(:,i))); 
    end
    figure,plot(local_snr)
    mean(local_snr)
end
