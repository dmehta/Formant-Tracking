function genAllVTRFigs()
%function genAllVTRFigs()
% Generate .pdf and .fig files for all utterances in VTR database,
% according to settings used in (Rudoy, Spendley, Wolfe, 2007).
% 
% Plots are labeled with utterance and other TIMIT info (gender, dialog,
% etc), and TIMIT phoneme segmentation boundaries are indicated.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Set parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% EKS or EKF (this just adjusts labels; need to match internally in 
% MyTrackExp.m
method = 'EKS';

% Boolean for enlarging plot text
boldenPlots = 1;

% Set target directory to write output
targetDir = 'D:\research\projects\formants\formant_track_lib\vtr_results';

% Fix parameters as reported in (Rudoy, Spendley, Wolfe, 2007).
% (See bottom for tabulation of other parameter settings)
quantThresh = [0.15]; % 0 for coasting off; 0.15 for coasting on
useCorr = [1];   % boolean variable (for VAR)
frmts =  {[1 2 3]};
coastJoint = [1];  % 1 (fixed boolean always)
sigExp = [1]; % 1 (fixed real always)
timitInd = 1:516; % 516 (fixed always; all VTR utterances)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Loop through all 516 VTR database entries, compute output, and save
% figures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loop Calls to MyTrackExp
numIters = length(timitInd);
t0 = clock;
for i = 1:numIters
    
    % Run tracker with appropriate parameter settings
    % (E will contain EKF or EKS as set internally in MyTrackExp)
    E = MyTrackExp('Timit',[],15,16000,3,[],[],timitInd(i), ...
        coastJoint(1),quantThresh(1),useCorr(1),sigExp(1),frmts{1});
    
    % Call plotting routine
    plotTrackers(E,method,boldenPlots);
    
    % Adjust, label, and save plot
    subplot(4,1,1);
    covs = getTimitCovariates(timitInd(i));
    textHandle = text(0,4750, ... % (longest sent ca. 80 characters)
        [covs.dialect ' ' covs.gender ': "' covs.sentence '"']);
    if boldenPlots, % this fontsize works, as longest ca. 80 characters
        set(textHandle,'FontSize',11);
    end
    subplot(4,1,4);
    textHandle = text(0,-1500,...
        ['RMSE figures averaged over 3 formants: ' ...
        'for entire utterance / conditioned on speech presence.']);
    if boldenPlots, % this fontsize works, as longest ca. 80 characters
        set(textHandle,'FontSize',11);
    end
    vtrNum = int2str(timitInd(i));
    set(gcf,'PaperPosition',[0 0 8.5 11]);
    % Print to pdf using default resolution (684--'-r864')
    print('-dpdf', [targetDir filesep vtrNum '.pdf']);

    % Show time progression
    if ~mod(i,25)
       display(['Iteration ' int2str(i) ' of ' int2str(numIters) ...
           '. Elapsed time: ' num2str(etime(clock,t0)) '.']);      
    end

end
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function timitCovs = getTimitCovariates(timitNum)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Load Timit utterance matfile
matFile = ['Timit' int2str(timitNum) '.mat'];
load(matFile);

% Get utterance text
sentenceLetterInd = find(isletter(data.sentence));
sentence = data.sentence(sentenceLetterInd(1):end);

% Get speaker gender
fnameFilesepInd = strfind(data.fileName,filesep);
genderInitial = data.fileName(fnameFilesepInd(end-1)+1);
switch lower(genderInitial)
    case 'f'
        gender = 'female';
    case 'm'
        gender = 'male';
    otherwise
        error('Error parsing gender string: neither male nor female');
end

% Get speaker dialect
dialectCode = data.fileName(fnameFilesepInd(end-1)-1);
switch lower(dialectCode)
    case '1'
        dialect = 'New England';
    case '2'
        dialect = 'Northern';
    case '3'
        dialect = 'North Midland';
    case '4'
        dialect = 'South Midland';
    case '5'
        dialect = 'Southern';
    case '6'
        dialect = 'New York City';
    case '7'
        dialect = 'Western';
    case '8'
        dialect = 'Army Brat';
    otherwise
        error('Error parsing dialect string: not between 1 and 8');
end

% Assign outputs and return
timitCovs.sentence = sentence;
timitCovs.gender = gender;
timitCovs.dialect = dialect;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function plotTrackers(E, method, boldenPlots)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Figure number to create/reuse
figHandle = 1;
figure(figHandle);
clf;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Errorbar Plot Code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute dimensions of formant tracks
numFormants = size(E.estVar,2);
numFrames = size(E.estVar,3);

% Create variables and store tracks and standard deviations
[tracks stDevs] = deal(zeros(numFormants,numFrames));
tracks = E.estTracks;
for i = 1:numFrames
    stDevs(:,i) = sqrt(diag(E.estVar(:,:,i)));
end

% Loop through formants and plot
% (done as loop owing to indicator vectors of varying size)
for i = 1:numFormants

    % Determine frames (per formant) without data
    dataPresenceBool = E.formantInds(:,i)';
    dataPresenceInds = find(dataPresenceBool==1);
    dataAbsenceInds =  find(dataPresenceBool==0);

     % Plot errorbars, but not during data absence
    % (since variance explodes...)
    subplot(4,1,4);
    hold on;
    timeAxis = (0:(numFrames-1)).*10/1000; 
    errorbar(timeAxis(dataPresenceInds),tracks(i,dataPresenceInds),...
        stDevs(i,dataPresenceInds),'c.');
    plot(timeAxis(dataPresenceInds),tracks(i,dataPresenceInds),'b.')
    plot(timeAxis(dataAbsenceInds),tracks(i,dataAbsenceInds),'m.')

    % Plot regions of speech absence and other tracks
    plot(timeAxis,E.wsState','k-')
    grid on
    title('Smoother (blue) and Wavesurfer (black)')

    % Plot errorbars, but not during data absence
    % (since variance explodes...)
    subplot(4,1,3);
    hold on;
    timeAxis = (0:(numFrames-1)).*10/1000; 
    errorbar(timeAxis(dataPresenceInds),tracks(i,dataPresenceInds),...
        stDevs(i,dataPresenceInds),'c.');
    plot(timeAxis(dataPresenceInds),tracks(i,dataPresenceInds),'b.')
    plot(timeAxis(dataAbsenceInds),tracks(i,dataAbsenceInds),'m.')

    % Plot regions of speech absence and other tracks
    plot(timeAxis,E.trueState(i,:),'k-')
    grid on
    title('Smoother (blue) and VTR (black)')

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Spectrogram 1 Code
subplot(4,1,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
winlen = floor(E.fs/1000*8);  % 8 ms to make plots clear
winlen = winlen + (mod(winlen,2)~=0); % force even
winoverlap = winlen/2; % 50pct overlap

% Plot first spectrogram and overlay estimated, true tracks
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;
myPlotSpecTracks(E,E.estTracks,'w','b');
myPlotSpecCoast(E,'m');
smootherRMSE = mean(E.rmse);
smootherRMSEAll = mean(E.rmseAll);
title(['Smoother (blue, avg. RMSE = ' int2str(smootherRMSEAll) ...
    ' / ' int2str(smootherRMSE) ' Hz) and VTR (white)']);
xlabel([]);
ylabel([]);
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Spectrogram 1 Code
subplot(4,1,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Plot second spectrogram and overlay Wavesurfer, true tracks
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;
myPlotSpecTracks(E,E.wsState,'w','k');
wavesurferRMSE = mean(E.ws_rmse);
wavesurferRMSEAll = mean(E.ws_rmseAll);
title(['WaveSurfer (black, avg. RMSE = ' int2str(wavesurferRMSEAll) ...
    ' / ' int2str(wavesurferRMSE) ' Hz) and VTR (white)']);
xlabel([]);
ylabel([]);
hold off

% Clean up plots
for i = 1:4
    subplot(4,1,i)
    setAxLims(gca,[timeAxis(1) timeAxis(end)],[0 E.fs/2]);
    if i == 4,
        setAxLabs(gca,'Time (s)','Frequency (Hz)');
    end
    increasePlotFontSize(figHandle,boldenPlots);
end
hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function increasePlotFontSize(figHandle,boldenPlots)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if boldenPlots
    figure(figHandle);
    warning off;
    my_fmakep5;
    warning off;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function setAxLims(axisHandle,xLimits,yLimits)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
set(axisHandle,'Xlim',xLimits);
set(axisHandle,'Ylim',yLimits);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function setAxLabs(axisHandle,xLabel,yLabel)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xlabel(axisHandle,xLabel);
ylabel(axisHandle,yLabel);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function myPlotSpecTracks(E,tracks,trueColor,estColor)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function overlays estimated formant tracks onto spectrogram 
% fs, wLength, and wOverlap are neccesary to convert frame index to time
% index as plotted by spectrogram

% Overlay Resonant Tracks onto Spectrogram
xScale = 1/E.fs*E.wLength*E.wOverlap;
xStart = xScale/2;
xInd = xStart:xScale:xStart+xScale*(size(tracks(1,:,1),2)-1);
len = min([size(tracks,2) ...
          size(E.trueState,2) ...
          size(E.estTracks,2) ...
          size(E.wsState,2)]);
plot(xInd(1:len),tracks(:,1:len,1)',[estColor '.']);
plot(xInd(1:len),E.trueState(:,1:len,1)',[trueColor '.']);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function myPlotSpecCoast(E,coastColor)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If coasting was used, function indicates at what samples coasting was
% implemented and plots them onto spectrogram

% For converting indices to time series
xScale = 1/E.fs*E.wLength*E.wOverlap;
xStart = xScale/2;
xInd = xStart:xScale:xStart+xScale*(size(E.estTracks(1,:,1),2)-1);

for i = 1:size(E.formantInds,2)
    
    % Find non-zero indices of mask
    inds = find(E.formantInds(:,i) == 0);
    
    % Convert indices to time scale
    timeInds = (inds-1).*xScale+xStart;

    % Overlay data onto plots
    plot(timeInds,E.estTracks(i,(inds),1)',[coastColor '.']);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


