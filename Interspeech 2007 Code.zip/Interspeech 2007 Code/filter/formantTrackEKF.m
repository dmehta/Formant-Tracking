function [m_up, P_up] = formantTrackEKF(data,pNoiseVar,oNoiseVar,fs,trBW_flag,BW_data,initial_state,F)
%function [m_up, P_up] = formantTrackEKF(data,pNoiseVar,oNoiseVar,fs,trBW_flag,BW_data,initial_state,F)
%
% Extended Kalman Filter for formant tracking (Deng et al., 2007)
% data - observed cepstral data
% pNoiseVar - process variance
% oNoiseVar - observation variance
% fs - sampling frequency of data (needed for cepstral map linearization step)
% trBW_flag - indicates averaged or time-varying formant bandwidths to be plugged in
% BW_data - formant bandwidth data to be used
% initial_state - initial state estimate (from which dimensionalities are determined)
% F - state transition matrix (the identity for canonical Kalman setup)

[cepOrder N] = size(data);
state_size = length(initial_state);

% Modify BW for linearization
BW_vector = genTrackBW(trBW_flag,BW_data);

%Initial covariance estimates
ind_mat = eye(length(pNoiseVar));

if length(pNoiseVar) == 1
    state_var = pNoiseVar*eye(state_size);
else
    for ii = 1:length(pNoiseVar)
        state_var(ii,:) = pNoiseVar(ii).*ind_mat(ii,:);
    end
end

R = diag(oNoiseVar);

%Initial State and Variance Estimate
m_pred = F*initial_state;
P_pred = F*state_var*F' + state_var;

%Loop for Kalman Filtering
for k = 1:N
    
    %Linearize about state
    [H h] = get_linear_obserII(m_pred(:,k), BW_vector(:,k), cepOrder, fs); 
     
    %Compute Gain 
    gain = P_pred(:,:,k)*H'*inv(H*P_pred(:,:,k)*H' + R);
     
    % Update steps
    m_up(:,k) = m_pred(:,k) + gain*(data(:,k)-(H*m_pred(:,k) + h));
    P_up(:,:,k) = P_pred(:,:,k) - gain*H*P_pred(:,:,k);
    
    % Compute prediction steps for all but the last step
    if k < N
        m_pred(:,k+1) = F*m_up(:,k);
        P_pred(:,:,k+1) = F*P_up(:,:,k)*F' + state_var;
    end
end
