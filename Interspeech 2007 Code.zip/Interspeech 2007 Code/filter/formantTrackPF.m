function [pmean, phist, Neff] = formantTrackPF(y, pNoiseVar, oNoiseVar, fs, trBW_flag, BW_data, initial_state, N)
%function [pmean, phist, Neff] = formantTrackPF(y, pNoiseVar, oNoiseVar, fs, trBW_flag, BW_data, initial_state, N)
% Particle filter for formant tracking (model of Deng et al., 2007)

% Get implicit dimensions from input arguments
[cep_order numIter] = size(y);
state_size = length(initial_state);

% Set flag for reflection of particles about 0 and Nyquist
% (Note that norm consts etc are not yet correct!)
reflect = 1;

% Set constants for cepstral recursion
% (fb2cp is not called!)
c1 = -pi/fs; c2 = -2*c1;
a_tmp = 1:cep_order;
b_tmp = 1:state_size;
a = a_tmp(ones(state_size,1),:);
b = b_tmp(ones(cep_order,1),:)';
clear a_tmp b_tmp

% Get bandwidth info
BW_vector = genTrackBW(trBW_flag,BW_data);

% Initialize particles
%samples = (sqrt(pNoiseVar)*randn(state_size,N) + repmat(initial_state, 1, N));
%samples = (randn(state_size,N) + repmat(initial_state, 1, N));
samples = repmat(initial_state, 1, N);
if reflect
    % Reflect about origin and Nyquist freq
    samples = abs(samples);
    inds = find(samples>fs/2);
    samples(inds) = fs/2-mod(samples(inds),fs/2);
end

% Create/initialize needed loop variables
allSamples = zeros(numIter, state_size, N);
pmean = zeros(state_size,numIter);
weights = 1/N*ones(1,N);
lweights = zeros(1,N);
for k = 1:numIter
    
    % Store samples
    allSamples(k,:,:) = samples;
    
    % Compute likelihood of every particle        
    curObs = y(:,k);
    for p = 1:N
        % Map each particle into cepstral domain
        curSample = samples(:,p);
        
        % Convert formant locations and bandwidths into a pre-specified number
        % of cepstral coefficients (c1,c1,a,b precomputed)
        % (Replaces call to fb2cp for speedup)
        BW = BW_vector(:,k);
        bw_term2 = 2*exp(c1*a.*(BW(b)))./a;
        C_int2 = bw_term2.*cos(c2*a.*curSample(b));
        tmp = sum(C_int2,1)';
        
        % Compute likelihood of 15 dimensional Gaussian
        diffSq = (tmp-curObs).^2;
        curWeight = exp(-sum(diffSq)/(2*oNoiseVar))+ 1e-99;       
        curlWeight = log(curWeight);
        lweights(1,p) = lweights(1,p) + curlWeight;

        %cov = oNoiseVar*eye(cep_order);
        %curWeight = mvnpdf(tmp, curObs ,cov);
    end

    %Find max weights
    maxLWeight = max(lweights);
    % Shift weights up
    lweights = lweights + (1-maxLWeight);
    
    % Exponentiate
    weights = exp(lweights);
    
    % Normalize weights
    weights = weights/sum(weights);
    
    % Compute posterior mean
    pmean(:,k) = samples*weights';
    
    % Check number of effective particles and resample if it is < N/2
    Neff(k) = 1/sum(weights*weights');
    if(Neff(k) < N/2)
        % Resample particles need to replace with stratified sampling later
        %newInds = randsample(N,N,true,weights); % Multinomial Resampling
        newInds = systematicR(1:1:N, weights');  % Systematic Resampling
        samples(:,1:N) = samples(:,newInds);
        weights = 1/N*ones(1,N); % Reset weights to 1/N
        lweights = zeros(1,N);   % Reset log weights to 0
    else
        % Do nothing
    end
    
    % Evolve samples according to model
    for p = 1:N
        curSample = samples(:,p);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        samples(:,p) = curSample + sqrt(pNoiseVar').*randn(state_size,1);
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    end
    if reflect 
        % Reflect about origin and Nyquist freq
        samples = abs(samples);
        inds = find(samples>fs/2);
        samples(inds) = fs/2-mod(samples(inds),fs/2);
    end
end
phist = []; %TODO: histogram posterior
