function [smooth_state, smooth_var] = formantTrackEKSmooth2(data, formantInds, pNoiseVar,oNoiseVar,fs,trBW_flag,BW_data,initial_state,F)
%function [smooth_state, smooth_var] = formantTrackEKSmooth(data,pNoiseVar,oNoiseVar,f_samp,trBW_flag,BW_data,initial_state,F)
% Extended Kalman Smoother for formant tracking (Deng et al., 2007)
%
% data - observed cepstral data
% formantInds - matrix of indicator variables for likelihood censoring
% pNoiseVar - process variance
% oNoiseVar - observation variance
% fs - sampling frequency of data (needed for cepstral map linearization step)
% trBW_flag - indicates averaged or time-varying formant bandwidths to be plugged in
% BW_data - formant bandwidth data to be used
% initial_state - initial state estimate (from which dimensionalities are determined)
% F - state transition matrix (the identity for canonical Kalman setup)

[cepOrder N] = size(data);
state_size = length(initial_state);

% Modify BW for linearization
BW_vector = genTrackBW(trBW_flag,BW_data);

%Initial covariance estimates
ind_mat = eye(length(pNoiseVar));

if length(pNoiseVar) == 1
    state_var = pNoiseVar*eye(state_size);
else
    for ii = 1:length(pNoiseVar)
        state_var(ii,:) = pNoiseVar(ii).*ind_mat(ii,:);
    end
end

R = diag(oNoiseVar);

%Initial State and Variance Estimate
m_pred = F*initial_state;
P_pred = F*state_var*F' + state_var;

%Loop for Kalman Filtering
for k = 1:N    
    %Linearize about state
    [H h] = get_linear_obserII(m_pred(:,k), BW_vector(:,k), cepOrder, fs); 

    % Pull out coasting indices
    curInds = formantInds(k,:);
    % Repeat mask for observation matrix
    mask = repmat(curInds,cepOrder,1);
    
    %Compute Gain 
    gain = P_pred(:,:,k)*H'*inv(H*P_pred(:,:,k)*H' + R);
    gain = gain.*mask'; % Knock out the gain as in Schmidt-Kalman filter
    
    % Update steps
    m_up(:,k) = m_pred(:,k) + gain*(data(:,k)-(H*m_pred(:,k) + h));
    P_up(:,:,k) = P_pred(:,:,k) - gain*H*P_pred(:,:,k);
    
    % Compute prediction steps for all but the last step
    if k < N
        F_k = F;
        for l = 1:length(curInds)
            if(curInds(l) == 0)
                F_k(l,:) = zeros(1,length(curInds));
                F_k(:,l) = zeros(length(curInds),1);
                F_k(l,l) = 1;
            end
        end
        m_pred(:,k+1) = F_k*m_up(:,k);
        P_pred(:,:,k+1) = F_k*P_up(:,:,k)*F_k' + state_var;
    end
end

%Kalman Smoothing: These are the Rauch, Tung and Striebel recursions
smooth_state(:,N) = m_up(:,N);
smooth_var(:,:,N) = P_up(:,:,N);

for k = (N-1):-1:1

    % Pull out coasting indices
    curInds = formantInds(k,:);

    % Compute prediction steps for all but the last step
    if k > 0
        F_k = F;
        for l = 1:length(curInds)
            if(curInds(l) == 0)
                F_k(l,:) = zeros(1,length(curInds));
                F_k(:,l) = zeros(length(curInds),1);
                F_k(l,l) = 1;
            end
        end
        var_pre(:,:,k) = F_k*P_up(:,:,k)*F_k' + state_var;
        sgain = P_up(:,:,k)*F_k'*inv(var_pre(:,:,k));
    end

    smooth_state(:,k) = m_up(:,k) + sgain*(smooth_state(:,k+1) - m_pred(:,k+1));
    smooth_var(:,:,k) = P_up(:,:,k)+sgain*(smooth_var(:,:,k+1)-P_pred(:,:,k+1))*sgain';
end
