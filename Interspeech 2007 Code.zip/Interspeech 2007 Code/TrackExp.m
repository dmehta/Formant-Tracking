function OutputStruct = TrackExp(testMethod,snr_dB,cep_order,fs_in,num_formants, dataFileName, wsFileName, sample_index,rand_state,randn_state)
%function OutputStruct = TrackExp(testMethod,snr_dB,cep_order,fs_in,num_formants,...
%                  dataFileName,wsFileName,sample_index,rand_state,randn_state)
%
% testMethod      = 'VTR';  % 'Synth', 'VTR', 'Praat', 'WS'
% snr_dB          = SNR in dB of observations in cepstral domain
% cep_order       = Order of cepstrum to be computed (later: make pitch-dep)
% fs_in           = sample rate of loaded/generated data
% num_formants    = num_formants in data file (or to be created)
% dataFileName    = dataFileName used for database load
% wsFileName      = fileName for 'truth' (applicable in case of 'Wave')
% sample_index    = VTR database sample index (if 'VTR' selected)
% rand_state      = initial state for rand()
% randn_state     = initial state for randn()
%
% Examples: % E = TrackExp('Synth',15,15,16000,7);
% E = TrackExp('VTR',15,15,16000,3,'trueVTRdata',[],2);
% E = TrackExp('Praat',15,15,10000,4,'data\other\ln_roy_10k.Formant'); % broken
% E = TrackExp('WS',15,15,10000,4,'data\other\ln.roy.10k.frm');
% E = TrackExp('Wave',[],15,10000,4,'data\other\ln.roy.10k.wav', 'data\other\ln_roy_10k.Formant');
% E = TrackExp('Wave',[],15,10000,4,'data\other\mlm.tea.10k.wav','data\other\mlm.tea.10k.Formant');
% E = TrackExp('Wave',[],15,8000,4,'data\other\timit45.wav','data\other\timit451Formant'); 
% E = TrackExp('Timit',[],15,16000,4);
% E = TrackExp('Timit',[],15,16000,4,[],'data\Timit1.frm',1);

%%%%%%%%%%%%% Script Varatiables and Model Parameter Setup %%%%%%%%%%%%%%%%
show_plots = 1; % Plot flag

% Timit parameters
timitDataSet = sample_index;
fs = 5000*2; % for resampling (if 4 formants)
%fs = 3750*2; % for resampling (if 3 formants)
 
% % Window parameters
% wType = 'hamming'; % window type
% wLengthMS  = 20;  % Length of window (in milliseconds)
% wOverlap = 0.5;  % Factor of overlap of window

% Analysis Parameters
lpcOrder = 12;   % Number of LPC Coefficients
peCoeff  = .7;   % Pre-emphasis factor

% Flag for controlling whether or not to use coasting
useCoast = 1;
if useCoast
    coastJoint = 0; % Coast all formants jointly, or not
    quantThresh = 0.2; % power quantile threshold for coasting 
end

% Noise Flags for VTR testing
trueONoise       = 1;    % 0 for independent generation and tracker oNoise
if(trueONoise==0), lambda = 10^2 ; end % If trueONoise=0, set regularization parameter
truePNoise       = 1;    % 0 for independent generation and tracker pNoise
if(truePNoise==0), scale = 1/20; end % If truePNoise=0, scale for now to avoid boundary problems...

% Bandwidth Decision Flags (averaging bandwidths over time)
BW_flag      = 0;                  % [For 'Synth' or 'VTR'] Select 1 to average, 0 for truth
trBW_flag    = 0;                  % Select 1 to average, 0 for truth for trackers

% Decision Flags for Tracking Processes, and parameters
EKF_flag        = 1;                % Select 1 to run, 0 not to
EKS_flag        = 1;                % Select 1 to run, 0 not to
PF_flag         = 0;                % Select 1 to run, 0 not to
num_part        = 100;              % Particle Filter Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set pathing
if 1,
  addpath([pwd filesep 'test']); addpath([pwd filesep 'data']);
  addpath([pwd filesep 'synthetic']); addpath([pwd filesep 'io']);
  addpath([pwd filesep 'plot']); addpath([pwd filesep 'filter']);  
  addpath([pwd filesep 'data' filesep 'other']);
end

% Fix random seeds, to allow for exact repetition or otherwise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~exist('rand_state','var')
    rand_state = sum(100*clock);
    display('Seeding rand generator according to clock')
else
    display('Resetting rand generator according to fixed input')
end
if ~exist('randn_state','var')
    pause(rand); % Try to decorrelate rand seed from randn seed
    randn_state = sum(100*clock);
    display('Seeding randn generator according to clock')
else
    display('Resetting randn generator according to fixed input')
end
rand('state',rand_state);
randn('state',randn_state);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%% Test Decisions %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Select for generating data from random walk model or using VTR track
switch testMethod
    
    case 'Synth' % Synthetic Data Test
        display('Generating state and observed data from model')

        % Special variables for Synthetic Testing
        numObser        = 100;
        initState       = 500 + 1000*(0:(num_formants-1))'; % Note: matched to track init
        initBW          = 80 + 40*(0:(num_formants-1));
        pNoiseVar       = 10^2;

        % Generate Data
        [trueState, y, oNoiseVar, BW_data] = genSyntheticDataSNR(pNoiseVar,snr_dB,fs_in,numObser,cep_order,initState,initBW);
        
    case {'VTR', 'Praat', 'WS'} % VTR or other comparative data test 
        switch testMethod
            case 'VTR'
                display(['Applying to example ' int2str(sample_index) ' of VTR database file ' dataFileName])
                [trueState, BW_data] = getDatabaseSeq(dataFileName,num_formants,sample_index,BW_flag);
            case 'Praat'
                display(['Reading data from Praat-generated file ' dataFileName])
                [trueState,BW_data] = praatFormantRead(dataFileName,num_formants);
            case 'WS'
                display(['Reading data from Wavesurfer-generated file ' dataFileName])
                [trueState,BW_data] = wavesurferFormantRead(dataFileName,num_formants);
        end

        % Generate Noisy Observations
        [y, oNoiseVar] = genNoisyObser(snr_dB,trueState,BW_data,cep_order,fs_in);

        % Get State Variance
        pNoiseVar = var(trueState');

    case {'Wave','Timit'} % Read waveform data file
        
        % Read in soundfile and ground-truth data
        switch testMethod
            case {'Wave'}
                display('Using wave file for observations')
                display(['Reading audio data from: ' dataFileName])
                wav = wavread(dataFileName);
                
                display(['Reading data from Wavesurfer-generated file ' wsFileName])
                [trueState,BW_data] = wavesurferFormantRead(wsFileName,num_formants);
        
            case {'Timit'}
                % Thus far have not found a good way to load data in directly
                % from the cell array, can only specify by variable  name
                display(['Reading audio data from VTRandTIMITtrain'])
                load VTRandTIMITtrain;
                curData = DATA{timitDataSet};
                display(['Using TIMIT data file: ' int2str(timitDataSet)]);
                display(['Utterance: ' curData.sentence]);
                
                % Read in VTR data and scale appropriately
                trueState = 1000*curData.vtrData(:,1:num_formants)';
                BW_data   = 500*curData.vtrData(:,5:(4+num_formants))';
                
                % Read in Wavesurfer output for comparison
                wsFileName = ['data\Timit' int2str(sample_index) '.frm']; % overwrites input!
                display(['Reading data from Wavesurfer-generated file ' wsFileName])
                [wsState,wsBW_data] = wavesurferFormantRead(wsFileName,num_formants);

                % Setup real data and parameters
                wav = curData.timitData;
                
                % Overwrite any possible user input
                wType = 'hamming'; % window type
                wLengthMS  = 20;  % Length of window (in milliseconds)
                wOverlap = 0.5;  % Factor of overlap of window

            otherwise
        end
        
        % Resample input data (TODO: make optional)        
        wav = resample(wav,fs,fs_in,2048);
        display(['Input Fs = ' int2str(fs_in) ' Hz; resampling to ' num2str(fs) ' Hz'])       

        % Compute Window AFTER ANY RESAMPLING
        wLength = floor(wLengthMS/1000*fs);
        wLength = wLength + (mod(wLength,2)~=0); % force even
        win = feval(wType,wLength); 
        display(['Processing input data with length-' num2str(wLength) ' ' wType ' window'])
        
        % Truncate the timit utterance (a la VTR database, we think)
        wav = wav(1:wLength*wOverlap*length(trueState));

        if trueONoise == 1
            % Drop AWGN into wav here
            [nosWav, aNoiseVar] = addSigNoise(wav,snr_dB);
        end
        
        % Generate cepstral data
        if useCoast
            if coastJoint
                display(['Coasting all formants jointly (quantile threshold ' num2str(quantThresh) ')' ])
            else
                display(['Coasting formants individually (quantile threshold ' num2str(quantThresh) ')' ])
            end
            % Generate Clean and noisey cepstral data
            [y, formantInds] = genLPCC2(wav, win, wOverlap, peCoeff, lpcOrder, cep_order, coastJoint, quantThresh, num_formants, fs);
            
            if trueONoise == 1
                [nosY, formantInds]= genLPCC2(nosWav, win, wOverlap, peCoeff, lpcOrder, cep_order, coastJoint, quantThresh, num_formants, fs);           
            end
       else
            display('No coasting of formants')
            y = genLPCC(wav, win, wOverlap, peCoeff, lpcOrder, cep_order);
            nosY = genLPCC(nosWav, win, wOverlap, peCoeff, lpcOrder, cep_order);
            formantInds = ones(size(y,2),num_formants);
        end
        
        % Calculate SNR of cepstral data
        if trueONoise
            [ySNRdB, oNoiseVar] = getCepSNR(y,nosY);
        end
        
        % Truncate at most one frame from output of LPCC call
        numFrames = size(y,2);
        trueState = trueState(1:num_formants,1:numFrames);
        BW_data = BW_data(1:num_formants,1:numFrames);
        
        % Get State Variance
        pNoiseVar = var(trueState');
        
        % Set "True" Observation Variances
        if not(trueONoise)
            oNoiseVar = 0;
            snr_dB = inf;
            display('Input snr_dB not used; setting obs noise variance to 0')
        else
            display('Input snr_dB used; setting oNoiseVar to corresponding value ')
        end     
    
    otherwise % Ran out of legitimate options
        display('Invalid Test Command');
        return;
end
display(['SNR = ' num2str(snr_dB) ' dB; cepstral order = ' int2str(cep_order)])
% Set/choose estimated observation noise variance
if truePNoise == 1
    pTNoiseVar = pNoiseVar;
    display('Using true process variance')
else % Artificially decrease "measured" state noise variance
    pTNoiseVar = pNoiseVar.*scale; % to avoid boundary problems; later,
    % need to estimate from observations
    display(['Using ' num2str(scale) '-rescaled true process variance'])
end;

% Set/choose estimated observation noise variance
if trueONoise == 1
    oTNoiseVar = oNoiseVar;
    display('Using true observation noise variance')
%    display(['Observation Noise Variance = ' num2str(oNoiseVar, '%1.4f')])
else
    oTNoiseVar = 1/lambda; % how to estimate this from data?
    display(['Using ' num2str(oTNoiseVar) ' as observation noise variance'])
    %display([' (True observation noise variance = ' num2str(oNoiseVar)'])
    % Above is broken, owing to array size issues...
end;

% Set initial state values (based on prior formant "belief")
[formant_state_size,numObser] = size(BW_data);
if formant_state_size~=num_formants, error('Formant size mismatch'); end
initial_state_est = 500 + 1000*(0:(formant_state_size-1))';
display(['Initial state estimates set at: ' num2str(initial_state_est')])

%Initial Plotting Variables
titleCell(1,1)  = {'True State'};   % Keeps track of trackers used for plotter
titleCell(2,1)  = {'r'};            % Color for true state plot

% Use noisey or truth data depending on trueONoise
if (trueONoise)
    yTrack = nosY;
else
    yTrack = y;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%% Tracking Algorithms %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
countTrack = 1;
% Run Extended Kalman Filter
if EKF_flag == 1

    % Run and time EK filter
    t0 = clock;   
    if useCoast
        [x_estEKF x_errVarEKF] = formantTrackEKF2(yTrack, formantInds, pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est);
    else
        [x_estEKF x_errVarEKF] = formantTrackEKF(yTrack,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est);
    end
        
    %Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = x_estEKF;%*2/3; % 10/16 or pi/5;
    estVar(:,:,:,countTrack) = x_errVarEKF;
    titleCell(1,countTrack+1) = {'EKF'};
    titleCell(2,countTrack+1) = {'g-.'};

    %Compute and Display MSE and RMSE
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,:,countTrack)-trueState(j,:)))/sqrt(numObser);
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,:)))*sqrt(numObser);
    end

    % Display output summary and timing information
    display(['Kalman Filter Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack)))]);

    % Increment counter
    countTrack = countTrack + 1;

end

% Run Extended Kalman Smoother
if EKS_flag == 1

    % Run and time EK smoother
    t0 = clock;
    if useCoast
        [x_estEKS x_errVarEKS] = formantTrackEKSmooth2(yTrack, formantInds, pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est);
    else
        [x_estEKS x_errVarEKS] = formantTrackEKSmooth(yTrack,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est);
    end
    
    % Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = x_estEKS;
    estVar(:,:,:,countTrack) = x_errVarEKS;
    titleCell(1,countTrack+1) = {'EKS'};
    titleCell(2,countTrack+1) = {'b:'};

    %Compute and Display MSE and RMSE
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,:,countTrack)-trueState(j,:)))/sqrt(numObser);
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,:)))*sqrt(numObser);
    end

    % Display output summary and timing information
    display(['Kalman Smoother Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack)))]);

    % Increment counter
    countTrack = countTrack + 1;

end

% Run Particle Filter
if PF_flag == 1;
    % Run and time particle filter
    t0 = clock;
    [pmean phist Neff] = formantTrackPF(y,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,num_part);

    %Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = pmean;
    titleCell(1,countTrack+1) = {'PF'};
    titleCell(2,countTrack+1) = {'c--'};

    %Compute and Display MSE and RMSE
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,:,countTrack)-trueState(j,:)))/sqrt(numObser);
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,:)))*sqrt(numObser);
    end

    % Display output summary and timing information
    display([int2str(num_part) '-Particle Filter Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack)))]);

    % Increment counter
    countTrack = countTrack + 1;
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% CREATE/ASSIGN OUTPUT STRUCT %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Assign input variables to output struct
OutputStruct.testMethod = testMethod;
OutputStruct.snr_dB = snr_dB;
%OutputStruct.cepSNR_dB = ySNRdB;
OutputStruct.cep_order = cep_order;
if strcmp(testMethod,'VTR'), OutputStruct.sample_index = sample_index; end
if strcmp(testMethod,'Timit'), OutputStruct.wav = wav; end
if strcmp(testMethod,'Wave'), OutputStruct.wav = wav; end
OutputStruct.rand_state = rand_state;
OutputStruct.randn_state = randn_state;
OutputStruct.wLength = wLength;
OutputStruct.wOverlap = wOverlap;
OutputStruct.formantInds = formantInds;
OutputStruct.wsState = wsState;
%Assign results to output struct
OutputStruct.trueState = trueState;
OutputStruct.estTracks = estTracks;
OutputStruct.rmse = rmse;
OutputStruct.relRmse = relRmse;
OutputStruct.fs = fs;
if (EKF_flag | EKS_flag), OutputStruct.estVar = estVar; end
%Assign results to output sub-struct
if EKF_flag == 1
    OutputStruct.EKF.state_correction = x_estEKF;
    OutputStruct.EKF.var_correction = x_errVarEKF;
end
if EKS_flag == 1
    OutputStruct.EKS.smooth_state = x_estEKS;
    OutputStruct.EKS.smooth_var = x_errVarEKS;
end
if PF_flag == 1
    OutputStruct.PF.pmean = pmean;
    OutputStruct.PF.phist = phist;
    OutputStruct.PF.Neff = Neff;
end

if show_plots
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%% PLOTTING ROUTINES %%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    warning off
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot States Separately
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotStateTracks(trueState,estTracks,titleCell)
    my_fmakep5; % Enlarge plot fonts
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot MSE for single run through
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotRMSE(trueState,estTracks,titleCell)
    my_fmakep5; % Enlarge plot fonts
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot States Together, and Specgram
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if strcmp(testMethod,'Timit')
        compareTrackers(OutputStruct,'EKS');
    end
    figure(3);
    axis tight
    ylim([0 fs/2])
    my_fmakep5
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Image the indices to see where the coasting occurs
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    if useCoast, 
        figure(6),clf, imagesc(formantInds'); 
    else
        figure(6); clf
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    warning on
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%