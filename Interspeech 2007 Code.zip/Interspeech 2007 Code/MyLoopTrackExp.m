function [rmse rmseAll] =  MyLoopTrackExp(timitInd,coastJoint,quantThresh,useCorr,sigExp,frmts)
%function rmse =  MyLoopTrackExp(timitInd,coastJoint,quantThresh,useCorr,sigExp,frmts)
% Function Loops MyTrackExp to process data examples specified by timitInd

% Loop Calls to MyTrackExp
numIters = length(timitInd);
t0 = clock;
for i = 1:numIters
    if ~mod(i,25)
       display(['Iteration ' int2str(i) ' of ' int2str(numIters) '. Elapsed time: ' num2str(etime(clock,t0)) '.']);      
    end
    E = MyTrackExp('Timit',[],15,16000,3,[],[],timitInd(i),coastJoint,quantThresh,useCorr,sigExp,frmts);
    rmse(:,:,i) = [E.rmse E.ws_rmse(:,1)];
    rmseAll(:,:,i) = [E.rmseAll E.ws_rmseAll(:,1)];
end

if 0
    % Compute RMSE mean and variance over all utterances
    mean_rmse = mean(rmse,3);
    [m n] = size(mean_rmse);
    var_rmse = zeros(m,n);
    for i = 1:m
        for j = 1:n
            var_rmse(i,j) = var(rmse(i,j,:));
        end
    end
    diff(mean_rmse')';

    % Plot RMSE per utterance
    k = 1;
    figure(7); 
    for i= 1:m
        for j= 1:n
            subplot(m,n,k);
            hold on; 
            plot(squeeze(rmse(i,j,:)),'b:');
            axis tight
            grid
            k = k+1;
        end
    end
end

% Various computations
%mean(rmse,3) % averaged over utterance
%mean(rmse,1) % averaged over formant
%mean(mean(rmse,3),1) % averaged over utterance, then formant

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Old Stuff (deprecated)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Flag Declarations
% mFlag = 0;  %Use masking technique to compute error
% eFlag = 0;  %Use if Extended Kalman Filter was used to track
% sFlag = 1;  %Use if smoother was used to track

% % Calculate Avg RMSE of WS, ASSUMING DATA IS ALLIGNED!!!!!!!!
% [EKFrmse EKFrelRmse EKSrmse EKSrelRmse WSrmse WSrelRmse numEst] = getAvgRMSE(E,mFlag,eFlag,sFlag);
% 
% % Plot Averaged MSE values
% plotAvgRMSE(EKFrmse,EKFrelRmse,EKSrmse,EKSrelRmse,WSrmse,WSrelRmse, numEst)
% 
% my_fmakep5;
% debug = 0;
