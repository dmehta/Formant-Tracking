function [] = plotSNRRes(EKFrmse, EKFrelRmse, EKSrmse, EKSrelRmse,SNRval)
%
% Function plots the results of the SNR tests for LoopTrackExp
% Created : 3/25/2007
% Last Updated : 3/25/2007

% Initialize Variables for Legend
cTrack = 0;
tCell = {};

figure;
if not(isempty(EKFrmse))
    plot(SNRval,EKFrmse',['-*']);
    hold on;
end
if not(isempty(EKSrmse))
    plot(SNRval,EKSrmse',['-o']);
end
grid on;
ylabel('Formant Number')
xlabel('SNR (dB)')
title('RMSE');
my_fmakep5;

figure;
if not(isempty(EKFrelRmse))
    plot(SNRval,EKFrelRmse',['-*']);
    tCell(cTrack+1) = {'EKF'};
    cTrack = cTrack + 1;
    hold on;
end
if not(isempty(EKSrelRmse))
    plot(SNRval,EKSrelRmse',['-o']);
    tCell(cTrack+1) = {'EKS'};
    cTrack = cTrack+1;
end
grid on;
ylabel('Formant Number')
xlabel('SNR (dB)')
title('Relative RMSE');
my_fmakep5;