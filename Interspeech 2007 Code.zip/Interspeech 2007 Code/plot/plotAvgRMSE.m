function plotAvgRMSE(EKFrmse,EKFrelRmse,EKSrmse,EKSrelRmse,WSrmse,WSrelRmse, numEst)
%
% Function plots the averaged mse and relRmse values for EKF, EKS and Wave
% Surfer
% Created : 3/23/2007
% Last Updated : 3/24/2007

% Initialize the number of formants and title cell and indice
tCell = {'WS'};
cTrack = 1;

figure();
subplot(1,2,1)
plot(WSrmse, '-ro');
hold on;
if not(isempty(EKFrmse))
    plot(EKFrmse, '-go');
end 
if not(isempty(EKSrmse))
    plot(EKSrmse, '-bo');  
end
grid on; 
xlim([0.5 numEst+0.5]);
title('Root MSE')
ylabel('RMSE (Hz)')
xlabel('Formant Number')
%legend('EKF','EKS', 'WS');

subplot(1,2,2)
plot(WSrelRmse,['-r' 'o']);
hold on;
if not(isempty(EKFrelRmse))
    plot(EKFrelRmse,['-g' 'o']);
    tCell(cTrack+1) = {'EKF'};
    cTrack = cTrack + 1;
end
if not(isempty(EKSrelRmse))
    plot(EKSrelRmse,['-b' 'o']);
    tCell(cTrack+1) = {'EKS'};
    cTrack = cTrack+1;
end
grid on;
xlim([0.5 numEst+0.5])
title('Relative Root MSE')
ylabel('RMSE Ratio')
xlabel('Formant Number')
legend(char(tCell(1:cTrack)));

