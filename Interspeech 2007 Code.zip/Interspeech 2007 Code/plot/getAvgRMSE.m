function [EKFrmse EKFrelRmse EKSrmse EKSrelRmse WSrmse WSrelRmse numEst] = getAvgRMSE(E,mFlag,eFlag,sFlag);
%
% Computes RMSE and RELRSME of EKF and WS using VTR database as truth.  Assumes
% data is already alligned.  Option to use mask when computing error.
% Calculations follow closely wiht plotRMSE.m
% 
% Created : 3/23/2007
% Last Updated : 3/24/2007

% Get number of loops and number of formants tracked
numLoops = size(E,2);
numEst = size(E(1).estTracks,1);

% Get the number of trackers used
%countTrack = E.countTrack;

% Place into workable data structures
for ii = 1:numLoops
    % Get Data, EKF will always be first tracker if present
    if eFlag == 1
        EKFState(:,:) = E(ii).estTracks(:,:,1);
    else
        EKFState = [];
    end

    if sFlag == 1
        if eFlag == 1
            EKSState(:,:) = E(ii).estTracks(:,:,2);
        else
            EKSState(:,:) = E(ii).estTracks(:,:,1);
        end
    else
        EKSState = [];
    end
    
    wsState(:,:) = E(ii).wsState;
    VTR(:,:) = E(ii).trueState;
    
    % Get number of formants and Frames
    %numEst = size(VTR,1);
    
    % Take minimum number of frames to be truth
    VTRFrames = size(VTR,2);
    WSFrames = size(wsState,2);
    numFrames = min([VTRFrames WSFrames]);
    
    %Truncate formant tracks
    wsState = wsState(:,1:numFrames);
    VTR = VTR(:,1:numFrames);
    if (eFlag)
        EKFState = EKFState(:,1:numFrames);
    else 
        EKFState = zeros(numEst,numFrames);
    end
    if (sFlag)
        EKSState = EKSState(:,1:numFrames);
    else
        EKSState = zeros(numEst,numFrames);
    end
    
    %If mFlag high, we'll mask to help compute error
    if mFlag == 1
        formantInds = E(ii).formantInds';
        formantInds = formantInds(:,1:numFrames);
        
        % Mask States
        EKFState = EKFState(:,:).*formantInds(:,:);
        wsState = wsState(:,:).*formantInds(:,:);
        VTR = VTR(:,:).*formantInds(:,:);
        EKSState = EKSState(:,:).*formantInds(:,:);
    end
    
    % Compute RMSE and relRmse
    for jj = 1:numEst
        
        if (eFlag)
            intEKFrmse(jj,:,ii) = norm((EKFState(jj,:)-VTR(jj,:)))/sqrt(numFrames);
            intEKFrelRmse(jj,:,ii) = (intEKFrmse(jj,:,ii)/norm(VTR(jj,:)))*sqrt(numFrames);    
        else
            intEKFrmse = [];
            intEKFrelRmse = [];
        end

        if (sFlag)
            intEKSrmse(jj,:,ii) = norm((EKSState(jj,:)-VTR(jj,:)))/sqrt(numFrames);
            intEKSrelRmse(jj,:,ii) = (intEKSrmse(jj,:,ii)/norm(VTR(jj,:)))*sqrt(numFrames);    
        else
            intEKSrmse = [];
            intEKSrelRmse = [];
        end
        
        intWSrmse(jj,:,ii) = norm((wsState(jj,:)-VTR(jj,:)))/sqrt(numFrames);
        intWSrelRmse(jj,:,ii) = (intWSrmse(jj,:,ii)/norm(VTR(jj,:)))*sqrt(numFrames);    
    end
    
    % Clear Variables
    clear EKFState;
    clear EKSState;
    clear wsState;
    clear VTR;
    clear formantInds;
    
end

% Compute averages, COULD USE A WEIGHTED MEAN
EKFrmse = mean(squeeze(intEKFrmse),2);
EKFrelRmse = mean(squeeze(intEKFrelRmse),2);
EKSrmse = mean(squeeze(intEKSrmse),2);
EKSrelRmse = mean(squeeze(intEKSrelRmse),2);
WSrmse = mean(squeeze(intWSrmse),2);
WSrelRmse = mean(squeeze(intWSrelRmse),2);

debug = 0;