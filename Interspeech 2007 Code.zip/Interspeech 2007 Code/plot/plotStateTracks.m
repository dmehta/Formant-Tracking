function plotStateTracks(trueState,estTracks,titleCell)
%function plotStateTracks(trueState,estTracks,titleCell)
% Plot estimated formant tracks vs. ground truth

% TODO: Make the loop dependent on state size

% Number of track estimates
numEst = size(estTracks,3);
numForms = size(trueState,1);

%Titles for plot legends
ii = 1:(numEst+1);
S = titleCell(1,ii);

% Assumes tracking all four formants
m = ceil(sqrt(numForms));
n = ceil(numForms/m);
figure(1); clf,
for ff = 1:numForms
    subplot(m,n,ff)
    plot(trueState(ff,:),char(titleCell(2,1)));
    grid on;
    hold on;
    for tt = 1:numEst
        plot(estTracks(ff,:,tt), char(titleCell(2,tt+1)));
    end
    title(['Resonance ' int2str(ff)]);
     if ff==1, 
         legend(char(S),'Location','NorthEast'); % Gets in the way for small plots!
     end
     if ff==(n*(m-1)+1)
        xlabel('Time Block');
        ylabel('Frequency (Hz)');
    end
end
