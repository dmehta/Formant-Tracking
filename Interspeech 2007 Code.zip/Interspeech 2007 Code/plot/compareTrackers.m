function compareTrackers(E, method)
% function compareTrackers(E)

if(strcmp(method,'EKF'))
    methodIndex = 1;
else if (strcmp(method,'EKS'))
        methodIndex = 2;
    else
        methodIndex = 3;
    end
end

E.estTracks = E.estTracks(:,:,methodIndex);

% Errorbar Plot Code
figure(3),clf; plot(E.trueState','g-')
figure(3),hold on;
plot(E.wsState','b.')
plot(E.estTracks','k.')

% plotEBars(E)
% plotCoast(E)
grid on;
title(['Tracker results: VTR (solid green), WS (blue dots), ' method ' (black dots)'])
my_fmakep5

% Spectrogram Code
winlen = floor(E.fs/1000*8);  % 8 ms to make plots clear
winlen = winlen + (mod(winlen,2)~=0); % force even
winoverlap = winlen/2; % 50pct overlap

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure(4); clf, subplot(2,1,1)
% specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
% hold on;
% 
% % Overlay Kalman Resonant Tracks onto Spectrogram
% plotSpecTracks(E,E.estTracks,'k')
% plotSpecCoast(E)
% title(['Tracker comparison: ' method ' (black) vs. VTR (white)'])
% xlabel([])
% ylabel([])
% 
% % Overlay Wavesurfer Resonant Tracks onto Spectrogram
% figure(4); subplot(2,1,2)
% specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
% hold on;
% plotSpecTracks(E,E.wsState,'k')
% title('Tracker comparison: Wavesurfer (blue) vs. VTR (white)')
% xlabel('Time (s)')
% ylabel('Frequency (Hz)')
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4); clf, subplot(2,1,1)
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;

% Overlay Kalman Resonant Tracks onto Spectrogram
plotSpecTracks(E,E.estTracks,'k')
plotSpecCoast(E)
title(['Extended Kalman Smoother'])
xlabel([])
ylabel([])

% Overlay Wavesurfer Resonant Tracks onto Spectrogram
figure(4); subplot(2,1,2)
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;
plotSpecTracks(E,E.wsState,'k')
title('WaveSurfer')
xlabel('Time (s)')
ylabel('Frequency (Hz)')
colormap hot
cmap = colormap; 
cmap=cmap(end:-1:1,:); 
colormap(cmap)
brighten(0.5)
my_fmakep5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Repeat, swap order
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(5); clf, subplot(2,1,2)
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;

% Overlay Kalman Resonant Tracks onto Spectrogram
plotSpecTracks(E,E.estTracks,'k')
plotSpecCoast(E)
title(['Tracker comparison: ' method ' (black) vs. VTR (white)'])
xlabel('Time (s)')
ylabel('Frequency (Hz)')

% Overlay Wavesurfer Resonant Tracks onto Spectrogram
figure(5); subplot(2,1,1),
specgram(E.wav,winlen,E.fs,hamming(winlen),winoverlap);
hold on;
plotSpecTracks(E,E.wsState,'b')
title('Tracker comparison: Wavesurfer (blue) vs. VTR (white)')
xlabel([])
ylabel([])
%my_fmakep5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

debug = 0;
