function [state_progression,BW_data] = getDatabaseSeq(filename,num_formants,sample_index,BW_flag)
%function [state_progression,BW_data] = getDatabaseSeq(filename,num_formants,sample_index,BW_flag)
% Generates Data for testing Deng Outline, for fixed bandwidths, and
% computes the noise to include for a given SNR using data base data
% Also adds the desired noise to the cepstrum coeffs

% Created : 3/3/2007
% Last Updated : 3/13/2007
% Dan Spendley

% Variable Declarations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Load Data
load(filename);

% Get Desired Data
freqs_and_BW = dataSets{sample_index}';
[rows columns] = size(freqs_and_BW);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plots to check work
% for ii = 1:columns
%     figure;
%     plot(state_progression(:,ii));
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Seperate State And Bandwidth Progression
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
state_progression = 1000*freqs_and_BW(1:num_formants,:); % VTR data in kHz!
BW_progression = freqs_and_BW(5:(4+num_formants),:);

% Compute Desired Bandwidth Progression
if BW_flag == 1
    for ii = 1:num_formants
        BW_mean(ii) = 500*mean(BW_progression(ii,:)); % VTR data in kHz!
    end
    BW_data = repmat(BW_mean',1,size(state_progression,2));
else
    BW_data = 500*BW_progression; % VTR data in kHz!
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
