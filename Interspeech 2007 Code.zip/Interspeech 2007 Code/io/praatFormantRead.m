function [f,bw] = praatFormantRead(fname,num_formants);
%function [f,bw] = praatFormantRead(fname,num_formants);
% Function to read Praat 4.22 Formant Tracker Output (.Formant files)
% 1. Load sound into Praat; choose "Formants & LPC"
% 2. Navigate to "To Formant (hack)"; then "To Formant (sl)"
% Choose default and compute formants
% (Navigate to "Draw" to display formants)
% Navigate to "Write" on main menu; 
% Select "Write to short text file"

% Open file and scan text data for numbers
fid = fopen(fname);
fdata = textscan(fid,'%f','headerLines',11);
fclose(fid);

% Formants
f = fdata{1}(1:2:end);
f((num_formants+1):(num_formants+1):end) = [];

num_frames = length(f)/num_formants;
if mod(num_frames,1)~=0,
    error('Incorrect indexing: non-integer number of frames')
end
f = reshape(f,num_formants,num_frames);

% Bandwidths
bw = fdata{1}(2:2:end);
bw((num_formants+1):(num_formants+1):end) = [];
bw = reshape(bw,num_formants,num_frames);
