function genIS07Res(runNum)
%function genIS07Res(runNum)
% Interspeech 2007 Submission: formant tracking script
% RunNum = 1 or 2, to generate Discussion (1) or Tables (2)

% Toggle mutiple runs
switch(runNum)
    case 1, % Toggle coasting on/off, toggle full VAR on/off (Discussion)
        quantThresh = [0 0.15]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [0 1];   % boolean variable (for VAR)
        frmts =  {[1 2 3]};
    case 2, % Coasting on, VAR on, vary VAR indices (Tables 1 and 2)
        quantThresh = [0.15]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [1];   % boolean variable (for VAR)
        frmts =  {[1 2], [2 3], [1 3]};
    case 3, % Coasting off, toggle full VAR, but compute error as if coasting
            % Have to modify the code explicitly to do this 
            % (uncomment line 219 of MyTrackExp) 
        quantThresh = [0.15]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [0 1];   % boolean variable (for VAR)
        frmts =  {[1 2 3]};
    case 4, % Test: Should be same as case 3 above
        % Have to modify the code explicitly to do this
        % (must __comment__ line 219 of MyTrackExp)
        quantThresh = [0]; % 0 for coasting off; 0.15 for coasting on
        useCorr = [0 1];   % boolean variable (for VAR)
        frmts =  {[1 2 3]};
    otherwise
        error('Invalid runNum specified');
end

% Fixed (empirically determined to be best) parameters
coastJoint = [1];  % 1 (fixed boolean always)
sigExp = [1]; % 1 (fixed real always)
timitInd = 1:516; % 516 (fixed always; all VTR utterances)

% Loop to run experiment and uniquely name result
for i = 1:length(coastJoint)
    for j = 1:length(quantThresh)
        for k = 1:length(useCorr)
            for m = 1:length(sigExp)
                for n = 1:length(frmts)
                    fInd = strtrim(int2str(frmts{n}));
                    fInd = fInd(find(~isspace(fInd)));
[rmse rmseAll] =  MyLoopTrackExp(timitInd,coastJoint(i),quantThresh(j),useCorr(k),sigExp(m),frmts{n});
save(['rmse_3_3500_cj' int2str(coastJoint(i)) '_qt' int2str(100*quantThresh(j)) 'nct_uc' int2str(useCorr(k)) 'm' fInd '_se' int2str(100*sigExp(m)) '_ws_av'],'rmse','rmseAll');
clear rmse rmseAll
                end
            end
        end
    end
end

