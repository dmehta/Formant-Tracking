function OutputStruct = TrackExp(testMethod,snr_dB,cep_order,fs_in,num_formants, dataFileName, wsFileName, sample_index,coastJoint,quantThresh,useCorr,sigExp,frmts,rand_state,randn_state)
%function OutputStruct = TrackExp(testMethod,snr_dB,cep_order,fs_in,num_formants,...
%                  dataFileName,wsFileName,sample_index,coastJoint,quantThresh,...
%                  useCorr,sigExp,frmts,rand_state,randn_state)
%
% testMethod      = 'VTR';  % 'Synth', 'VTR', 'Praat', 'WS'
% snr_dB          = SNR in dB of observations in cepstral domain
% cep_order       = Order of cepstrum to be computed (later: make pitch-dep)
% fs_in           = sample rate of loaded/generated data
% num_formants    = num_formants in data file (or to be created)
% dataFileName    = dataFileName used for database load
% wsFileName      = fileName for 'truth' (applicable in case of 'Wave')
% sample_index    = VTR database sample index (if 'VTR' selected)
% coastJoint      = coast formants jointly or not
% quantThresh     = threshold for coasting, as a quantile setting 
% useCorr         = use of VAR correlation structure from wavesurfer output
% sigExp          = noise variance divisor exponent
% frmts           = Number of formants to include in VAR model
% rand_state      = initial state for rand()
% randn_state     = initial state for randn()
%
% Examples: % E = TrackExp('Synth',15,15,16000,7);
% E = TrackExp('VTR',15,15,16000,3,'trueVTRdata',[],2);
% E = TrackExp('Praat',15,15,10000,4,'data\other\ln_roy_10k.Formant'); % broken
% E = TrackExp('WS',15,15,10000,4,'data\other\ln.roy.10k.frm');
% E = TrackExp('Wave',[],15,10000,4,'data\other\ln.roy.10k.wav', 'data\other\ln_roy_10k.Formant');
% E = TrackExp('Wave',[],15,10000,4,'data\other\mlm.tea.10k.wav','data\other\mlm.tea.10k.Formant');
% E = TrackExp('Wave',[],15,8000,4,'data\other\timit45.wav','data\other\timit45.Formant');
% E = TrackExp('Timit',[],15,16000,4);
% E = MyTrackExp('Timit',[],15,16000,3,[],[],1,1,0.15,1,1:3);
    
%%%%%%%%%%%%% Script Varatiables and Model Parameter Setup %%%%%%%%%%%%%%%%
global SHOW_TEXT; SHOW_TEXT = 1; % Text output flag
show_plots = 1; % Plot flag
if show_plots, plotRes = 'EKF'; end % result to plot

% Timit parameters
timitDataSet = sample_index;
%fs = 4750*2; % for resampling (if 4 formants)
fs = 3500*2; % for resampling (if 3 formants)

% Correlation control
if useCorr
    %frmts = 1:num_formants;  % Formants whose VAR structure is to be modeled
    diagCorr = 0; % Set to 0 if VAR(1) to 1 when 4 ind AR models
    wsTruth  = 1; % Set to 0 if to estimate matrix from VTR or to 1 for WS
end

% Analysis Parameters
lpcOrder = 12;   % Number of LPC Coefficients
peCoeff  = 0.7;   % Pre-emphasis factor

% Flag for controlling whether or not to use coasting
useCoast = 1;

% Noise Flags for VTR testing
trueONoise       = 0;    % 0 for independent generation and tracker oNoise
if(trueONoise==0), lambda = 10^0; end % If trueONoise=0, set regularization parameter
getVar = 'WS';
truePNoise       = 1;    % 0 for independent generation and tracker pNoise
if(truePNoise==0), scale = 1/10; end % If truePNoise=0, scale for now to avoid boundary problems...

% Bandwidth Decision Flags (averaging bandwidths over time)
useWsBWData  = 1;    % Bool to use WaveSurfer (rather than VTR for now) BW data
if useWsBWData, avgWsBWData  = 1; end % Bool to average WS Bandwidth (if useWsBWData  = 1;)
BW_flag      = 0;    % [For 'Synth' or 'VTR'] Select 1 to average, 0 for truth
trBW_flag    = 0;    % Select 1 to average, 0 for truth for trackers

% Decision Flags for Tracking Processes, and parameters
EKF_flag        = 1;                % Select 1 to run, 0 not to
EKS_flag        = 0;                % Select 1 to run, 0 not to
PF_flag         = 0;                % Select 1 to run, 0 not to
if PF_flag,   num_part = 100; end
RBPF_flag       = 0;                % Select 1 to run, 0 not to
if RBPF_flag, num_part_RB = 100; end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set pathing
if 1,
    addpath([pwd filesep 'test']); addpath([pwd filesep 'data']);
    addpath([pwd filesep 'synthetic']); addpath([pwd filesep 'io']);
    addpath([pwd filesep 'plot']); addpath([pwd filesep 'filter']);
    %addpath([pwd filesep 'data' filesep 'other']);
end

% Fix random seeds, to allow for exact repetition or otherwise
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ~exist('rand_state','var')
    rand_state = sum(100*clock);
    showText('Seeding rand generator according to clock');
else
    showText('Resetting rand generator according to fixed input');
end
if ~exist('randn_state','var')
%    pause(rand); % Try to decorrelate rand seed from randn seed
    showText('Clock decorrelator removed for speedup (not used for EKF, EKS)');
    randn_state = sum(100*clock);
    showText('Seeding randn generator according to clock');
else
    showText('Resetting randn generator according to fixed input');
end
rand('state',rand_state);
randn('state',randn_state);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%% Test Decisions %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Select for generating data from random walk model or using VTR track
switch testMethod

    case 'Synth' % Synthetic Data Test
        showText('Generating state and observed data from model');

        % Special variables for Synthetic Testing
        numObser        = 100;
        initState       = 500 + 1000*(0:(num_formants-1))'; % Note: matched to track init
        initBW          = 80 + 40*(0:(num_formants-1));
        pNoiseVar       = 10^2;

        % Generate Data
        [trueState, y, oNoiseVar, BW_data] = genSyntheticDataSNR(pNoiseVar,snr_dB,fs_in,numObser,cep_order,initState,initBW);

    case {'VTR', 'Praat', 'WS'} % VTR or other comparative data test
        switch testMethod
            case 'VTR'
                showText(['Applying to example ' int2str(sample_index) ' of VTR database file ' dataFileName]);
                [trueState, BW_data] = getDatabaseSeq(dataFileName,num_formants,sample_index,BW_flag);
            case 'Praat'
                showText(['Reading data from Praat-generated file ' dataFileName]);
                [trueState,BW_data] = praatFormantRead(dataFileName,num_formants);
            case 'WS'
                showText(['Reading data from Wavesurfer-generated file ' dataFileName]);
                [trueState,BW_data] = wavesurferFormantRead(dataFileName,num_formants);
        end

        % Generate Noisy Observations
        [y, oNoiseVar] = genNoisyObser(snr_dB,trueState,BW_data,cep_order,fs_in);

        % Get State Variance
        pNoiseVar = var(trueState');

    case {'Wave','Timit'} % Read waveform data file

        % Read in soundfile and ground-truth data
        switch testMethod
            case {'Wave'}
                showText('Using wave file for observations');
                showText(['Reading audio data from: ' dataFileName]);
                wav = wavread(dataFileName);

                showText(['Reading data from Wavesurfer-generated file ' wsFileName]);
                [trueState,BW_data] = wavesurferFormantRead(wsFileName,num_formants);

            case {'Timit'}
                % Thus far have not found a good way to load data in directly
                % from the cell array, can only specify by variable  name
                matFile = ['Timit' int2str(sample_index) '.mat'];
                showText(['Reading audio data from data\' matFile]);
                load(matFile);
                curData = data;
                showText(['Using TIMIT data file: ' int2str(timitDataSet)]);
                showText(['Utterance: ' curData.sentence]);

                % Read in VTR data and scale appropriately
                trueState = 1000*curData.vtrData(:,1:num_formants)';
                BW_data   = 500*curData.vtrData(:,5:(4+num_formants))';

                % Read in Wavesurfer output for comparison
                wsFileName = ['data\Timit' int2str(sample_index) '.frm']; % overwrites input!
                showText(['Reading data from Wavesurfer-generated file ' wsFileName]);
                [wsState,wsBW_data] = wavesurferFormantRead(wsFileName,num_formants);
                wsBW_data = wsBW_data((5-num_formants):4,:); % Hack fix for now; fix function above
                
                if useWsBWData
                    showText('Using WaveSurfer Bandwith Data');
                    BW_data(:,1:length(wsBW_data)) = wsBW_data./2;
                else % for now, this statement is true
                    showText('Using Fixed Nominal BW Data');
                    BW_nominal = [80 120 150 200]';
                    BW_data = repmat(BW_nominal(1:num_formants),1,length(BW_data));
                end
                
                % Setup real data and parameters
                wav = curData.timitData;

                % Overwrite any possible user input
                wType = 'hamming'; % window type
                wLengthMS  = 20;  % Length of window (in milliseconds)
                wOverlap = 0.5;  % Factor of overlap of window

            otherwise
        end
        
        % Resample input data (TODO: make optional)
        wav = resample(wav,fs,fs_in,2048);
        showText(['Input Fs = ' int2str(fs_in) ' Hz; resampling to ' num2str(fs) ' Hz']);

        % Compute Window AFTER ANY RESAMPLING
        wLength = floor(wLengthMS/1000*fs);
        wLength = wLength + (mod(wLength,2)~=0); % force even
        win = feval(wType,wLength);
        showText(['Processing input data with length-' num2str(wLength) ' ' wType ' window']);

        % Truncate the timit utterance (a la VTR database, we think)
        wav = wav(1:wLength*wOverlap*length(trueState));

        % Generate cepstral data
        if useCoast
            if coastJoint
                showText(['Coasting all formants jointly (quantile threshold ' num2str(quantThresh) ')' ]);
            else
                showText(['Coasting formants individually (quantile threshold ' num2str(quantThresh) ')' ]);
            end
            [y, formantInds] = genLPCC2(wav, win, wOverlap, peCoeff, lpcOrder, cep_order, coastJoint, quantThresh, num_formants, fs);
            formantIndsRMSE = formantInds;
            %formantInds = ones(size(y,2),num_formants); % Normally, this line should be commented!
            showText('Fix me later :)')
        else
            showText('No coasting of formants')
            y = genLPCC(wav, win, wOverlap, peCoeff, lpcOrder, cep_order);
            formantInds = ones(size(y,2),num_formants);
        end

        % (Hack) Make everything the same size
        % (This should go away when we rationalize wavesurfer, VTR, genLPCC, etc)
        numFrames = min([size(trueState,2) size(wsState,2) size(y,2) size(formantInds,1)]);
        y = y(:,1:numFrames);
        trueState = trueState(1:num_formants,1:numFrames);
        BW_data = BW_data(1:num_formants,1:numFrames);
        wsState = wsState(1:num_formants,1:numFrames);
        wsBW_data = wsBW_data(:,1:numFrames);
        formantInds = formantInds(1:numFrames,1:num_formants);
        formantIndsRMSE = formantIndsRMSE(1:numFrames,1:num_formants);
        
        if useCorr
            % Pull out correct data from which to estimate F
            if wsTruth
                dataTmp = wsState(:,formantInds(:,1)==1);   % Uses Wavesurfer truth
            else
                dataTmp = trueState(:,formantInds(:,1)==1); % Uses VTR truth
            end

            % TODO: Fix re the below warning
            if ~coastJoint,
                warning('VAR Fitting, EKF coasting, and Wavesurfer BW averaging incorrect unless formants coasted jointly'); 
            end

            % Estimate individual model
            if diagCorr
                for dim = 1:num_formants
                    ar(dim) = fitVAR(dataTmp(dim,:)',1);
                end
                estF = diag(ar);
                % Estimate joint model
            else
                %estF = fitVAR(dataTmp',1); % full VAR
                estF = fitVAR(dataTmp(frmts,:)',1); % formants specified by 'frmts' only
                tmpVar = eye(num_formants);
                tmpVar(frmts,frmts) = estF;
                estF = tmpVar;
            end
        end
        
        if (useWsBWData & avgWsBWData)
            BW_dataTmp = BW_data(:,formantInds(:,1)==1);
            BW_data = repmat(mean(BW_dataTmp,2),1,size(BW_data,2));
        end
        
        % Get State Variance
        switch getVar
            case 'WS'
                pNoiseVar = var(wsState(formantInds==1)');
            case 'VTR'
                pNoiseVar = var(trueState(formantInds==1)');
            otherwise
                error('Must select state variance setting: ''WS'' or ''VTR''')
        end

        % Set "True" Observation Variances
        oNoiseVar = 0;
        snr_dB = inf;
        [cVars] = analyzeResidual(y,wsState, trueState, formantInds, trBW_flag, BW_data, cep_order, fs);
        showText('Input snr_dB not used; setting obs noise variance to 0');

    otherwise % Ran out of legitimate options
        error('Invalid Test Command');
        return;
end

showText(['SNR = ' num2str(snr_dB) ' dB; cepstral order = ' int2str(cep_order)]);
% Set/choose estimated observation noise variance
if truePNoise == 1
    pTNoiseVar = pNoiseVar;
    showText('Using true process variance');
else % Artificially decrease "measured" state noise variance
    pTNoiseVar = pNoiseVar.*scale; % to avoid boundary problems; later,
    % need to estimate from observations
    showText(['Using ' num2str(scale) '-rescaled true process variance']);
end;

% Set/choose estimated observation noise variance
if trueONoise == 1
    oTNoiseVar = oNoiseVar;
    showText('Using true observation noise variance');
else
    oTNoiseVar = 1/lambda.*ones(cep_order,1)./(((1:cep_order).^sigExp)'); %sqrt(cVars); % how to estimate this from data?
    showText(['Using ' num2str(oTNoiseVar(1)) ' as observation noise variance']);
    %showText([' (True observation noise variance = ' num2str(oNoiseVar)'])
    % Above is broken, owing to array size issues...
end;

% Set initial state values (based on prior formant "belief")
[formant_state_size,numObser] = size(BW_data);
if formant_state_size~=num_formants, error('Formant size mismatch'); end
initial_state_est = 500 + 1000*(0:(formant_state_size-1))';
showText(['Initial state estimates set at: ' num2str(initial_state_est')]);

%Initial Plotting Variables
titleCell(1,1)  = {'True State'};   % Keeps track of trackers used for plotter
titleCell(2,1)  = {'r'};            % Color for true state plot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%% Tracking Algorithms %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
countTrack = 1;
% Run Extended Kalman Filter
if EKF_flag == 1

    % Run and time EK filter
    t0 = clock;    
    if useCorr
        F = estF;
    else
        F = eye(num_formants);
    end
       
    if useCoast        
        [x_estEKF x_errVarEKF] = formantTrackEKF2(y, formantInds, pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,F);
    else
        [x_estEKF x_errVarEKF] = formantTrackEKF(y,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,F);
    end

    %Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = x_estEKF;
    estVar(:,:,:,countTrack) = x_errVarEKF;
    titleCell(1,countTrack+1) = {'EKF'};
    titleCell(2,countTrack+1) = {'g-.'};

    %Compute and Display MSE and RMSE (exact copy of code from EKS below)
    len = min([size(trueState,2) ...
          size(estTracks,2) ...
          size(wsState,2)]);
    formantIndsTmp = formantIndsRMSE(1:len,:);
    ind = formantIndsTmp == 1;                % compute MSE only when not coasting  
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmse(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmse(j,countTrack) = (ws_rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    ind = ones(size(formantIndsTmp)) == 1; % now compute MSE everywhere
    for j = 1:formant_state_size
        rmseAll(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmseAll(j,countTrack) = (rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmseAll(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmseAll(j,countTrack) = (ws_rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
 
    % Display output summary and timing information
    showText(['Kalman Filter Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack))) ' vs. ' num2str(mean(ws_rmse(:,countTrack))) ' (WS)']);

    % Increment counter
    countTrack = countTrack + 1;

end

% Run Extended Kalman Smoother
if EKS_flag == 1

    % Run and time EK smoother
    t0 = clock;    
    if useCorr
        F = estF;
    else
        F = eye(num_formants);
    end

    if useCoast
        [x_estEKS x_errVarEKS] = formantTrackEKSmooth2(y, formantInds, pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,F);
    else
        [x_estEKS x_errVarEKS] = formantTrackEKSmooth(y,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,F);
    end

    % Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = x_estEKS;
    estVar(:,:,:,countTrack) = x_errVarEKS;
    titleCell(1,countTrack+1) = {'EKS'};
    titleCell(2,countTrack+1) = {'b:'};
    
    %Compute and Display MSE and RMSE (exact copy of code from EKF above)
    len = min([size(trueState,2) ...
          size(estTracks,2) ...
          size(wsState,2)]);
    formantIndsTmp = formantIndsRMSE(1:len,:);
    ind = formantIndsTmp == 1;                % compute MSE only when not coasting  
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmse(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmse(j,countTrack) = (ws_rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    ind = ones(size(formantIndsTmp)) == 1; % now compute MSE everywhere
    for j = 1:formant_state_size
        rmseAll(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmseAll(j,countTrack) = (rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmseAll(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmseAll(j,countTrack) = (ws_rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    
    % Display output summary and timing information
    showText(['Kalman Smoother Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack)))  ' vs. ' num2str(mean(ws_rmse(:,countTrack))) ' (WS)']);

    % Increment counter
    countTrack = countTrack + 1;

end

% Run Particle Filter
if PF_flag == 1;
    % Run and time particle filter
    t0 = clock;
    [pmean phist Neff] = formantTrackPF(y,pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,num_part);

    %Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = pmean;
    titleCell(1,countTrack+1) = {'PF'};
    titleCell(2,countTrack+1) = {'c--'};

    %Compute and Display MSE and RMSE (exact copy of code from EKF above)
     len = min([size(trueState,2) ...
          size(estTracks,2) ...
          size(wsState,2)]);
    formantIndsTmp = formantIndsRMSE(1:len,:);
    ind = formantIndsTmp == 1;                % compute MSE only when not coasting  
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmse(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmse(j,countTrack) = (ws_rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    ind = ones(size(formantIndsTmp)) == 1; % now compute MSE everywhere
    for j = 1:formant_state_size
        rmseAll(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmseAll(j,countTrack) = (rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmseAll(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmseAll(j,countTrack) = (ws_rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end

    % Display output summary and timing information
    showText([int2str(num_part) '-Particle Filter Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack))) ' vs. ' num2str(mean(ws_rmse(:,countTrack))) ' (WS)']);

    % Increment counter
    countTrack = countTrack + 1;
end

% Execute Rao-Blackwellized Particle Filter
if RBPF_flag == 1
    % Run and time Rao-Blackwellized particle filter
    t0 = clock;           
    if useCorr
        F = estF;
    else
        F = eye(num_formants);
    end
    [x_estRBPF x_errVarRBPF,pEst] = formantTrackRBPF(num_part_RB, y, formantInds, pTNoiseVar,oTNoiseVar,fs,trBW_flag,BW_data,initial_state_est,F);

    %showText(['MMSE estimate of lambda: ' num2str(1/pEst)]);  % 'MMSE' doesn't make sense here...
    %Track estimate into data cube for plot routines
    estTracks(:,:,countTrack) = x_estRBPF;
    %estVar(:,:,:,countTrack) = x_errVarRBPF; FIX THIS LATER
    titleCell(1,countTrack+1) = {'EKF'};
    titleCell(2,countTrack+1) = {'g-.'};

    %Compute and Display MSE and RMSE (exact copy of code from EKF above)
     len = min([size(trueState,2) ...
          size(estTracks,2) ...
          size(wsState,2)]);
    formantIndsTmp = formantInds(1:len,:);
    ind = formantIndsTmp == 1;                % compute MSE only when not coasting  
    for j = 1:formant_state_size
        rmse(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmse(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmse(j,countTrack) = (ws_rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    ind = ones(size(formantIndsTmp)) == 1; % now compute MSE everywhere
    for j = 1:formant_state_size
        rmseAll(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        relRmseAll(j,countTrack) = (rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end
    for j = 1:formant_state_size
        ws_rmseAll(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
        ws_relRmseAll(j,countTrack) = (ws_rmseAll(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
    end

    % Display output summary and timing information
    display(['RBPF Run Time: ' num2str(etime(clock,t0)) ' s. Average RMSE: ' num2str(mean(rmse(:,countTrack)))  ' vs. ' num2str(mean(ws_rmse(:,countTrack))) ' (WS)']);

    % Increment counter
    countTrack = countTrack + 1;
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%% CREATE/ASSIGN OUTPUT STRUCT %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Assign input variables to output struct
OutputStruct.testMethod = testMethod;
OutputStruct.snr_dB = snr_dB;
OutputStruct.cep_order = cep_order;
if strcmp(testMethod,'VTR'), OutputStruct.sample_index = sample_index; end
if strcmp(testMethod,'Timit'), OutputStruct.wav = wav; end
if strcmp(testMethod,'Wave'), OutputStruct.wav = wav; end
OutputStruct.rand_state = rand_state;
OutputStruct.randn_state = randn_state;
OutputStruct.wLength = wLength;
OutputStruct.wOverlap = wOverlap;
OutputStruct.formantInds = formantInds;
OutputStruct.wsState = wsState;
%Assign results to output struct
OutputStruct.trueState = trueState;
OutputStruct.estTracks = estTracks;

OutputStruct.rmse = rmse;
OutputStruct.relRmse = relRmse;
OutputStruct.ws_rmse = ws_rmse;

OutputStruct.rmseAll = rmseAll;
OutputStruct.relRmseAll = relRmseAll;
OutputStruct.ws_rmseAll = ws_rmseAll;

OutputStruct.fs = fs;
if (EKF_flag | EKS_flag), OutputStruct.estVar = estVar; end
%Assign results to output sub-struct
if EKF_flag == 1
    OutputStruct.EKF.state_correction = x_estEKF;
    OutputStruct.EKF.var_correction = x_errVarEKF;
end
if EKS_flag == 1
    OutputStruct.EKS.smooth_state = x_estEKS;
    OutputStruct.EKS.smooth_var = x_errVarEKS;
end
if PF_flag == 1
    OutputStruct.PF.pmean = pmean;
    OutputStruct.PF.phist = phist;
    OutputStruct.PF.Neff = Neff;
end

if show_plots
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%% PLOTTING ROUTINES %%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    warning off
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot States Separately
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotStateTracks(trueState,estTracks,titleCell)
    my_fmakep5; % Enlarge plot fonts
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot MSE for single run through
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    plotRMSE(trueState,estTracks,titleCell)
    my_fmakep5; % Enlarge plot fonts
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Plot States Together, and Specgram
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if strcmp(testMethod,'Timit')
        compareTrackers(OutputStruct,plotRes);
    end
    figure(3);
    axis tight
    ylim([0 fs/2])
    my_fmakep5
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %Image the indices to see where the coasting occurs
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if useCoast,
        figure(6),clf, imagesc(formantInds'); axis xy
    else
        figure(6); clf
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    warning on
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HELPER FUNCTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function showText(str)
global SHOW_TEXT 
if SHOW_TEXT
    disp(str)
end

% TODO:
% function [rmse relRmse ws_rmse ws_relRmse ] = calcRMSE(estTracks,wsState,trueState,formantInds,countTrack,formant_state_size)
% 
% %Compute and Display MSE and RMSE (exact copy of code from EKS below)
% len = min([size(trueState,2) ...
%     size(estTracks,2) ...
%     size(wsState,2)]);
% formantIndsTmp = formantInds(1:len,:);
% ind = formantIndsTmp == 1;
% if mseCoast
%     ind = ones(size(formantIndsTmp)) == 1; % compute MSE everywhere
% end
% for j = 1:formant_state_size
%     rmse(j,countTrack) = norm((estTracks(j,ind(:,j),countTrack)-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
%     relRmse(j,countTrack) = (rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
% end
% for j = 1:formant_state_size
%     ws_rmse(j,countTrack) = norm((wsState(j,ind(:,j))-trueState(j,ind(:,j))))/sqrt(length(ind(:,j)));
%     ws_relRmse(j,countTrack) = (ws_rmse(j,countTrack)/norm(trueState(j,ind(:,j))))*sqrt(length(ind(:,j)));
% end
