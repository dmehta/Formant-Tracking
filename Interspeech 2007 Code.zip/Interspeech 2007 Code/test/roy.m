% roy.m - script to experiment with voiced utterance
load royPraat4For
[x,fs] = wavread('ln.roy.10k.wav');

winlen = 250;
figure,plot(trueState')
figure,spectrogram(x,gausswin(winlen),ceil(winlen*3/4),[],fs,'yaxis')
