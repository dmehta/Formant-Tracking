% Function for looking at the residual variances in the cepstral domain
% using the input of all three algorithms
%
% INPUT
%   y          - Cepstrum of real data
%   wsState    - Output from Wavesurfer
%   vtrState   - Output form VTR Database
%   mask       - Indices for coasting and not
%   trBW_flag  - How to compute BW
%   BW_data    - Bandwidth data (currently supplied from VTR = Wavesurfer?)
function [cVars] = analyzeResidual(y,wsState, vtrState, mask, trBW_flag, BW_data, cepOrder, fs)
%[cVars] = analyzeResidual(y,wsState, trueState, formantInds, trBW_flag, BW_data, cep_order, fs);

% Obtain BW data the same way for all three algorithms
BW_vector = genTrackBW(trBW_flag,BW_data);

% First line up all the lengths
minLen = min([length(wsState) length(vtrState)]);
% Truncate
y         = y(:,1:minLen);
wsState   = wsState(:,1:minLen);
vtrState  = vtrState(:,1:minLen);
BW_vector = BW_vector(:,1:minLen);
mask      = mask(1:minLen,:)';

j = 1;
for k = 1:minLen
    curInds = mask(:,k);
    if(sum(curInds) == length(curInds))
        cepWS(:,j)  = fb2cp(wsState(:,j),BW_vector(:,j),cepOrder,fs);
        cepVTR(:,j) = fb2cp(vtrState(:,j),BW_vector(:,j),cepOrder,fs);
        ypred(:,j) = y(:,j);
        j = j+1;
    else
        % Do nothing
    end
end

% Compute difference between real data and WS data per cep. coeff
diff = cepWS - ypred;
% %diff = cepVTR - ypred;
% for i = 1:cepOrder
%     cVars(i) = var(diff(i,:)-mean(cepWS(i,:))+ mean(y(i,:)));
% end
cVars = diag(cov(diff'));

if 0
    figure;
    imagesc(log(abs(diff)));
    figure;
    begin = 2;
    x = begin:cepOrder;
    plot(x,cVars(begin:end));
    hold on;
    disp(mean(cVars));
    plot(x,cVars(begin)./sqrt(x),'-r')
    plot(x,cVars(begin)./x,'-g')
    plot(x,cVars(begin)./x.^2,'-c')
end