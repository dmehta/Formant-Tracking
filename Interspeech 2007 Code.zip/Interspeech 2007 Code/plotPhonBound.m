function [] = plotPhonBound(E,bounds)
%function [] = plotPhonBound(E,color)
%
% Function overlays phoneme boundaries as stated from TIMIT database
% Inputs include the OutputStruct and a vector of phoneme boundaries as
% as perceived from their corresponding sample values in the analog
% waveform
% Created : 3/26/2007
% Last Updated : 3/26/2007

% Produce Window Boundaries
boundVec = 1:(E.wLength)*(E.wOverlap):length(E.wav);

% Loop to check which window the phoneme starts
for ii = 1:length(bounds)
    % Bin boundry
    n = histc(bounds(ii),boundVec);
    
    % Determine which window boundry lies, boundary will be always be
    % lowerbounded
    ind(ii) = find(n);
    
    % Clear binning variable for next loop
    clear n;
end

% Calculate the spectrogram's x-scale
xScale = 1/E.fs*E.wLength*E.wOverlap;
xStart = xScale/2;
xInd = xStart:xScale:xStart+xScale*(size(E.wsState(1,:,1),2)-1);

% Map windows to the spectrogram's x-scale
phonBounds = xInd(ind);

% Plot Bounds on Spectrogram
for ii = 1:length(phonBounds)
    plot([phonBounds(ii),phonBounds(ii)],[0,E.fs/2],'k');
end

my_fmakep5;

debug = 0;
    